import React, { useEffect, useState } from "react";
import io from "socket.io-client";

// const socket = io("http://127.0.0.1/");


// socket.on("pesan_dari_server", (data) => {
//     console.log('berhasil konek ', data);
// });

// socket.disconnect();

const SocketSensor = () => {
    return (
        <div>
            ahadgadgahdgh
        </div>
    )
}

export default SocketSensor;