const Jumbotron = (props) => {
    console.log(props)
    return (
        <>
            <div className='tron'>
            </div>
        </>
    )
}

export default Jumbotron